document.getElementById("date").innerHTML =
new Date().toDateString();

document
.getElementById("contactForm")
.addEventListener("submit",function(e){

e.preventDefault();

let name =
document.getElementById("name").value.trim();

let email =
document.getElementById("email").value.trim();

let message =
document.getElementById("message").value.trim();

let emailPattern =
/^[^\s@]+@[^\s@]+\.[^\s@]+$/;

if(name===""){
    alert("Enter Name");
    return;
}

if(!emailPattern.test(email)){
    alert("Enter Valid Email");
    return;
}

if(message.length<10){
    alert("Message should contain at least 10 characters");
    return;
}

alert("Message Sent Successfully!");

this.reset();

});

function addTask(){

let taskInput =
document.getElementById("taskInput");

let task =
taskInput.value.trim();

if(task===""){
    alert("Enter Task");
    return;
}

let li =
document.createElement("li");

li.innerHTML=
`${task}
<button class="delete"
onclick="removeTask(this)">
Delete
</button>`;

document
.getElementById("taskList")
.appendChild(li);

taskInput.value="";

updateCount();
}

function removeTask(btn){

btn.parentElement.remove();

updateCount();
}

function updateCount(){

let total =
document.querySelectorAll("#taskList li").length;

document.getElementById("count")
.innerText = total;
}